typedef struct dict {
  char id;
  int value;
} t_dict;
